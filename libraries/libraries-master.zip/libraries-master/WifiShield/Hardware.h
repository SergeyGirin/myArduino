#ifndef HARDWARE_H
#define HARDWARE_H

#define WIFLY_RST 49
#define WIFLY_GPIO6 76

#endif // HARDWARE_H
